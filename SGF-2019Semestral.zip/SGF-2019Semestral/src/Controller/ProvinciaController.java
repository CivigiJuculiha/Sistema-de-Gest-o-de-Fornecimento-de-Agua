/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author MILG-PC
 */
//import 
import Model.StringDateOPeration;
import Model.Pais;
import Model.Provincia;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
public class ProvinciaController extends StringDateOPeration {
    
    private final String INSERT_QUERY = "INSERT INTO Provincia (idPais,NomeProvincia,dataCadastro,status) VALUES (?,?,?,?)";
    private final String UPDATE_QUERY = "UPDATE Provincia SET idPais=?,nomeProvincia=? WHERE idProvincia=?";
    private final String DELETE = "DELETE FROM Provincia WHERE idProvincia=?";
    private String getIdQuery="Select idProvincia FROM Provincia Where nomeProvincia=?";
      private String getProvinciaQuery="Select nomeProvincia FROM Provincia Where  idProvincia=?";
    private final String LIST = "Select* FROM Provincia";
    ///
    public boolean Add(Provincia p){
            boolean r=false;
            if(p!=null){
                PreparedStatement pstm;
                Connection conn=null;
               try {
                    conn=Conexao.getConnection();
                    pstm=conn.prepareStatement(INSERT_QUERY);
                    pstm.setInt(1,p.getIdPais());
                    pstm.setString(2,p.getNomeProvincia());
                    pstm.setString(3,p.getDataCadastro());
                    pstm.setBoolean(4,p.isStatus());
                    pstm.execute();
                    r=true;
                   Conexao.closeConnection(conn, pstm);
                } catch (Exception e) {
                    r=false;
                    JOptionPane.showMessageDialog(null,"Erro no metodo Adicionar Provincia:"+e.getMessage());
                }  
            }else{
                r=false;    
                JOptionPane.showMessageDialog(null,"Dados enviados por parametro estão vázio");
            }
            return r;
     }
    
     public boolean Update(Provincia pr){
            boolean r=false;
            if(pr!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(UPDATE_QUERY);
                pstm.setInt(1,pr.getIdPais());
                pstm.setString(2,pr.getNomeProvincia());
                pstm.setInt(3,pr.getIdProvincia());
                pstm.execute();
                r=true;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Erro ao Alterar dados da provincia"+" "+ e.getMessage());
                    r=false;
                }
            }else {
                JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
                r=false;
        }
            return r;
    }
     
    public void Delete(int idProvincia) {
        Connection conn = null;
        try {
            conn = Conexao.getConnection();
            PreparedStatement pstm;
            pstm = conn.prepareStatement(DELETE);
            pstm.setInt(1, idProvincia);
            pstm.execute();
            JOptionPane.showMessageDialog(null,"Dado Eliminado.");
            Conexao.closeConnection(conn, pstm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir provincia:"+"Erro"+" " + e.getMessage());
        }
    }
    
    public ArrayList<Provincia> ReadProvincia() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Provincia> Listacl = new ArrayList<Provincia>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(LIST);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Provincia  p = new Provincia();
                p.setIdPais(rs.getInt("idPais"));
                p.setIdProvincia(rs.getInt("idProvincia"));
                p.setNomeProvincia(rs.getString("nomeProvincia"));
                p.setDataCadastro(rs.getString("dataCadastro"));
                p.setStatus(rs.getBoolean("status"));
                Listacl.add(p);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Provincia"+" " + e.getMessage());
        }
        return Listacl;
    }

   public void populaComboBoxProvincia(JComboBox cboProvincia){
        String sqlSelect="Select* From Provincia";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboProvincia.addItem(rs.getString("nomeProvincia"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox Provinca:"+e.getMessage());
        }
    }
   public void populaComboBoxProvinciaWithIdPais(JComboBox cboProvincia, int idPais){
        String sqlSelect="Select* From Provincia where idPais like'"+idPais+"'";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboProvincia.addItem(rs.getString("nomeProvincia"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox Provinca:"+e.getMessage());
        }
    }
   
   public int getIdProvincia(String nomeProvincia){
       int id=0;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getIdQuery);
            pstm.setString(1,nomeProvincia);
            rs=pstm.executeQuery();
            while(rs.next()){
                id=rs.getInt("idProvincia");
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar id da Provincia:"+e.getMessage());
        }
       return id;
    }
    public String getProvincia(int idPro){
       String nomeProvincia=null;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getProvinciaQuery);
            pstm.setInt(1,idPro);
            rs=pstm.executeQuery();
            while(rs.next()){
                nomeProvincia=rs.getString("nomeProvincia");
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar nome da Provincia:"+e.getMessage());
        }
       return nomeProvincia;
    }

    
}