/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author MILG-PC
 */
import Model.Cliente;
import Model.Pais;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class PaisController {
    String nomePais;
    private String Insert="Insert Into Pais (nomeDePais,dataCadastro,status) values(?,?,?)";
    private String update="UPDATE Pais set nomeDePais=? WHERE idPais=?";
    private String List="Select* From Pais";
    private String Delete="DELETE  From Pais Where idPais=?";
    private String getIdQuery="Select idPais FROM pais Where nomeDePais=?";
    private String getPaisQuery="Select nomeDePais FROM pais Where idPais=?";
    private String searchQuery="Select* From pais Where nomeDepais like ?";
        public boolean Add( Pais p){
            boolean r=false;
            if(p!=null){
                PreparedStatement pstm;
                Connection conn=null;
               try {
                    conn=Conexao.getConnection();
                    pstm=conn.prepareStatement(Insert);
                    pstm.setString(1,p.getNomeDePais());
                    pstm.setString(2,p.getDataCadastro());
                    pstm.setBoolean(3,p.isStatus());
                    pstm.execute();
                    r=true;
                   Conexao.closeConnection(conn, pstm);
                } catch (Exception e) {
                    r=false;
                    JOptionPane.showMessageDialog(null,"Erro no metodo Adicionar Pais:"+e.getMessage());
                }  
            }else{
                r=false;
                JOptionPane.showMessageDialog(null,"Dados enviados por parametro estão vázio");
            }
            return r;
        }
    public boolean Update(Pais p){
      boolean r=false;
      if(p!=null){
           Connection conn=null;
           PreparedStatement pstm=null;
           try {
               conn=Conexao.getConnection();
               pstm=conn.prepareStatement(update);
               pstm.setString(1,p.getNomeDePais());
               pstm.setInt(2, p.getIdPais());
               pstm.execute();
               r=true;
               Conexao.closeConnection(conn, pstm);                       
          } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro no método Actualizar Pais:"+e.getMessage());
          }
      }else{
          JOptionPane.showMessageDialog(null,"Dados enviados por parametro estãol váizio");
      }
        return r;
    }
   
    public void populaComboBoxPais(JComboBox cboPais){
        String sqlSelect="Select* From Pais";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboPais.addItem(rs.getString("nomeDePais"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox Pais:"+e.getMessage());
        }
    }
   public int getIdPais(String nomePais){
       int id=0;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getIdQuery);
            pstm.setString(1,nomePais);
           // pstm=
            rs=pstm.executeQuery();
            while(rs.next()){
                id=rs.getInt("idPais");
            }
           Conexao.closeConnection(conn, pstm);       
                    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar id do pais:"+e.getMessage());
        }
       return id;
    }
public  List<Pais> pesquisarPais(String nome){
       ArrayList<Pais> listaPais = new ArrayList<Pais>();
       PreparedStatement pstm=null;
        Connection conn=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(searchQuery);
            pstm.setString(1,"%"+nome+"%");
            rs=pstm.executeQuery();
            while(rs.next()){
                        Pais p=new Pais();
                        p.setIdPais(rs.getInt("idPais"));
                        p.setNomeDePais(rs.getString("nomeDePais"));
                        p.setDataCadastro(rs.getString("dataCadastro"));
                        p.setStatus(rs.getBoolean("status"));
            }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,"Erro no metodo Filtrar pais:"+e.getMessage());
    }finally{
        Conexao.closeConnection(conn, pstm);
            
        }
        return listaPais;
}

public ArrayList<Pais> ReadPais() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Pais> Listacl = new ArrayList<Pais>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(List);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Pais  p = new Pais();
                p.setIdPais(rs.getInt("idPais"));
                p.setNomeDePais(rs.getString("nomeDePais"));
                p.setDataCadastro(rs.getString("DataCadastro"));
                p.setStatus(rs.getBoolean("status"));
                Listacl.add(p);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar País"+" " + e.getMessage());
        }
        return Listacl;
    }
public void Delete(int id) {
        Connection conn = null;
        try {
            conn = Conexao.getConnection();
            PreparedStatement pstm;
            pstm = conn.prepareStatement(Delete);
            pstm.setInt(1, id);
            pstm.execute();
             JOptionPane.showMessageDialog(null, "Dado removido...");
            Conexao.closeConnection(conn, pstm);
 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir Pais do banco de"
                    + "dados " + e.getMessage());
        }
    }
 public String getPais(int idPais){
       String nomePais=null;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getPaisQuery);
            pstm.setInt(1,idPais);
            rs=pstm.executeQuery();
            while(rs.next()){
                nomePais=rs.getString("nomeDePais");
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar nome do pais:"+e.getMessage());
        }
       return nomePais;
    }

}
