/* * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Bairro;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


/**
 *
 * @author MILG-PC
 */
public class BairroController extends JFrame{
    JTextField txtNomeux;
   private final String INSERT_QUERY = "INSERT INTO Bairro (idDistrito,nomeBairro,dataCadastro) VALUES (?,?,?)";
    
    private final String UPDATE_QUERY = "UPDATE Bairro SET idDistrito=?,nomeBairro=? WHERE idBairro=?";
    private final String getIdQuery="Select idDistrito Where nomeDistrito=?";
    private final String DELETE = "DELETE FROM Bairro WHERE idBairro=?";
    private final String LIST = "SELECT* FROM Bairro";
    private final String LISTBYNOMEUSERNAME = "SELECT * FROM Distrito WHERE NomeCompleto=? AND UserName=?";
    private final String GetByIdUsuario = "SELECT * FROM Usuario WHERE idBairro=?";
    
     public boolean Add(Bairro b){
            boolean r=false;
            if(b!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(INSERT_QUERY);
                pstm.setInt(1,b.getIdDistrito());
                pstm.setString(2,b.getNomeBairro());
                pstm.setString(3,b.getDataCadastro());
                pstm.execute();
                r=true;
                } catch (Exception e) {
                   JOptionPane.showMessageDialog(null, "Erro ao regsitar Bairro"
                        + " dados "+ " " + e.getMessage());
                    r=false;
                }
            }else {
            JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
            r=false;
        }
            return r;
    }
     public boolean Update(Bairro b){
            boolean r=false;
            if(b!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(UPDATE_QUERY);
                pstm.setInt(1,b.getIdDistrito());
                pstm.setString(2,b.getNomeBairro());
                pstm.setInt(3, b.getIdBairro());
                pstm.execute();
                r=true;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Erro ao Alterar dados do Bairro"
                        +" "+ e.getMessage());
                    r=false;
                }
            }else {
            JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
            r=false;
        }
            return r;
    }
     public boolean Delete(int idDistrito) {
        Connection conn = null;
        boolean r=false;
        try {
            conn = Conexao.getConnection();
            PreparedStatement pstm;
            pstm = conn.prepareStatement(DELETE);
            pstm.setInt(1, idDistrito);
            pstm.execute();
            Conexao.closeConnection(conn, pstm);
            r=true;
        } catch (Exception e) {
            r=false;
            JOptionPane.showMessageDialog(null, "Erro ao excluir Distrito do banco de dado:"+"Erro"+" " + e.getMessage());
        }
        return r;
    }
   public List<Bairro> readBairro() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Bairro> ListaBairro= new ArrayList<Bairro>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(LIST);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Bairro bb = new Bairro();
                bb.setIdDistrito(rs.getInt("idDistrito"));
                bb.setIdBairro(rs.getInt("idBairro"));
                bb.setNomeBairro(rs.getString("NomeBairro"));
                bb.setDataCadastro(rs.getString("dataCadastro"));
                ListaBairro.add(bb);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Bairro"+" " + e.getMessage());
        }
        return ListaBairro;
    }
     public void populaComboBoxBairro(JComboBox cboBairro){
        String sqlSelect="Select* From Bairro";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboBairro.addItem(rs.getString("NomeBairro"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox bairro:"+e.getMessage());
        }
    }
    public void populaComboBoxBairroWithIdDistrito(JComboBox cboBairro, int idDistrito){
        String sqlSelect="Select* From Bairro Where idDistrito like '"+idDistrito+"'";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboBairro.addItem(rs.getString("NomeBairro"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox bairro:"+e.getMessage());
        }
    }
   public int getIdBairro(String nomeBairro){
       int id=0;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getIdQuery);
            pstm.setString(1,nomeBairro);
            rs=pstm.executeQuery();
            while(rs.next()){
                id=rs.getInt("idBairro");
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar id do Bairro:"+e.getMessage());
        }
       return id;
    }
   public String getBairro(int idBairro){
       String bairro=null;
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=pstm.getConnection();
            pstm.setInt(1,idBairro);
            rs=pstm.executeQuery();
            while(rs.next()){
            bairro=rs.getString("NomeBairro");
            }
            Conexao.closeConnection(conn,pstm);
        } catch (Exception e) {
           JOptionPane.showMessageDialog(null,"Erro no metodo que retorna Bairro:"+e.getMessage());
       }
        return bairro;
   }
   
}
