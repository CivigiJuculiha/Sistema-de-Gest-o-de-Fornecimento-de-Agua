/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author MILG-PC
 */
public class ContratoController {
    private final String INSERT = "INSERT INTO Contrato (Nome,Bi,Sexo,Provincia,Bairro,NrCasa,quarteirao,Telefone,Email,Status,TipoDeContrato,ValorDeAbertura,consumoMinimo,DataCadastro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";/*,?,?,?,?,?*/
  /*,,,*/////
  private final String UPDATE = "UPDATE Cliente SET NOME=?,Bi=?,Sexo=?,Provincia=?,Bairro=?,NrCasa=?,Quarteirao=?, TELEFONE=?, EMAIL=?,Status=?, TipoDeContrato=? WHERE ID=?";
  private final String DELETE = "DELETE FROM Cliente WHERE ID =?";
  private final String LIST = "SELECT * FROM Cliente";
  private final String LISTBYNOME = "SELECT * FROM Cliente WHERE NOME=?";
  private final String LISTBYID = "SELECT * FROM Cliente WHERE ID=?";
  private final String GIVEid="SELECT* FROM Cliente";
  
    
}
