/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import sun.security.util.ECUtil;

/**
 *
 * @author MILG-PC
 */
public class ClienteController {
      String nomePais;
    private String Insert="Insert Into Cliente (nomeDoCliente,tipoDocumento,nrDocumento,dataNascimento,localEmissao,estadoCivil,pais,provincia,Distrito,Bairro, NCasa,sexo,Telefone,Email,dataCadastro,status) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    private String update="UPDATE Cliente  SET nomeDoCliente=?,tipoDocumento=?,nrDocumento=?,dataNascimento=?,localEmissao=?,estadoCivil=?,pais=?,provincia=?,Distrito=?,Bairro=?,NCasa=?,status=?,sexo=?,Telefone=?,Email=? WHERE IdCliente=?";
    private String List="Select* From Cliente";
    private String LogicalDelete="UPDATE Cliente set status=? WHERE idCliente=?";
    private String Delete="DELETE From Cliente Where idCliente=?";
    private String getIdQuery="Select idCliente FROM Cliente Where nomeDoCliente=?";
    private String getClienteQuery="Select* FROM Cliente Where idCliente=?";
    private String searchQuery="Select* From Cliente Where nomeDoCliente like ?";
        public boolean Add(Cliente c){
            boolean r=false;
            if(c!=null){
                PreparedStatement pstm;
                Connection conn=null;
               try {
                    conn=Conexao.getConnection();
                    pstm=conn.prepareStatement(Insert);
                    
                    pstm.setString(1,c.getNomeDoCliente());
                    pstm.setString(2,c.getTipoDeDocumento());
                    pstm.setString(3,c.getNrDocumento());
                    
                    pstm.setString(4,c.getDataDeNascimento());
                    pstm.setString(5,c.getLocalDeEmissao());
                    pstm.setString(6,c.getEstadoCivil());
                    
                    pstm.setString(7,c.getPais());
                    pstm.setString(8,c.getProvincia());
                    pstm.setString(9,c.getDistrito());
                    
                    pstm.setString(10,c.getBairro());
                    pstm.setInt(11,c.getNCasa());
                    pstm.setString(12,c.getSexo());
                    pstm.setInt(13, c.getTelefone());
                    pstm.setString(14,c.getEmail());
                    pstm.setString(15,c.getDataCadastro());
                    pstm.setBoolean(16,c.getStatus());
                    pstm.execute();
                    r=true;
                   Conexao.closeConnection(conn, pstm);
                } catch (Exception e) {
                    r=false;
                    JOptionPane.showMessageDialog(null,"Erro no metodo Adicionar Cliente:"+e.getMessage());
                }  
            }else{
                r=false;
                JOptionPane.showMessageDialog(null,"Dados enviados por parametro estão vázio");
            }
            return r;
        }
    public boolean Update(Cliente c){
      boolean r=false;
      if(c!=null){
           Connection conn=null;
           PreparedStatement pstm=null;
           try {
               conn=Conexao.getConnection();
               pstm=conn.prepareStatement(update);
                    pstm.setString(1,c.getNomeDoCliente());
                    pstm.setString(2,c.getTipoDeDocumento());
                    pstm.setString(3,c.getNrDocumento());
                    pstm.setString(4,c.getDataDeNascimento());
                    pstm.setString(5,c.getLocalDeEmissao());
                    pstm.setString(6,c.getEstadoCivil());
                    
                    pstm.setString(7,c.getPais());
                    pstm.setString(8,c.getProvincia());
                    pstm.setString(9,c.getDistrito());
                    
                    pstm.setString(10,c.getBairro());
                    pstm.setInt(11,c.getNCasa());
                    pstm.setBoolean(12,c.getStatus());
                    pstm.setString(13, c.getSexo());
                    pstm.setInt(14,c.getTelefone());
                    pstm.setString(15,c.getEmail());
                    pstm.setInt(16,c.getIdPessoa());
                    pstm.execute();
                    r=true;
               Conexao.closeConnection(conn, pstm);                       
          } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro no método Actualizar Cliente:"+e.getMessage());
          }
      }else{
          JOptionPane.showMessageDialog(null,"Dados enviados por parametro estãol váizio");
      }
        return r;
    }
   
   public int getIdCliente(String nomeDoCliente){
       int id=0;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getIdQuery);
            pstm.setString(1,nomeDoCliente);
           // pstm=
            rs=pstm.executeQuery();
            while(rs.next()){
                id=rs.getInt("idCliente");
            }
           Conexao.closeConnection(conn, pstm);       
                    
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar id do cliente:"+e.getMessage());
        }
       return id;
    }
public  List<Cliente> pesquisarCliente(JTextField cliente){
       ArrayList<Cliente> listaCliente = new ArrayList<Cliente>();
       PreparedStatement pstm=null;
        Connection conn=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(searchQuery);
            pstm.setString(1,"%"+cliente+"%");
            rs=pstm.executeQuery();
            while(rs.next()){
                        Cliente c=new Cliente();
                        c.setIdPessoa(rs.getInt("idCliente"));
                        c.setIdPessoa(rs.getInt("nomeDoCliente"));
                        c.setIdPessoa(rs.getInt("tipoDocumento"));
                        c.setIdPessoa(rs.getInt("nrDocumento"));
                        c.setIdPessoa(rs.getInt("dataNascimento"));
                        c.setIdPessoa(rs.getInt("localEmissao"));
                        c.setIdPessoa(rs.getInt("estadoCivil"));
                        c.setIdPessoa(rs.getInt("pais"));
                        c.setIdPessoa(rs.getInt("provincia"));
                        c.setIdPessoa(rs.getInt("Distrito"));
                        c.setIdPessoa(rs.getInt("Bairro"));
                        c.setIdPessoa(rs.getInt("NCasa"));
                        c.setIdPessoa(rs.getInt("dataCadastro"));
                        c.setIdPessoa(rs.getInt("status"));
            }
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,"Erro no metodo Filtrar Cliente:"+e.getMessage());
    }finally{
        Conexao.closeConnection(conn, pstm);
            
        }
        return listaCliente;
}

public ArrayList<Cliente> ReadCliente() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Cliente> Listacliente = new ArrayList<Cliente>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(List);
            rs = pstm.executeQuery();
            while (rs.next()) {
                   Cliente c=new Cliente();
                        c.setIdPessoa(rs.getInt("idCliente"));
                        c.setNomeDoCliente(rs.getString("nomeDoCliente"));
                        c.setTipoDeDocumento(rs.getString("tipoDocumento"));
                        c.setNrDocumento(rs.getString("nrDocumento"));
                        c.setDataDeNascimento(rs.getString("dataNascimento"));
                        c.setLocalDeEmissao(rs.getString("localEmissao"));
                        c.setEstadoCivil(rs.getString("estadoCivil"));
                        c.setPais(rs.getString("pais"));
                        c.setProvincia(rs.getString("provincia"));
                        c.setDistrito(rs.getString("Distrito"));
                        c.setBairro(rs.getString("Bairro"));
                        c.setNCasa(rs.getInt("NCasa"));
                        c.setEmail(rs.getString("Email"));
                        c.setSexo(rs.getString("Sexo"));
                        c.setDataCadastro(rs.getString("dataCadastro"));
                        c.setStatus(rs.getBoolean("status"));
                Listacliente.add(c);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Cliente"+" " + e.getMessage());
        }
        return Listacliente;
    }
public void DeleteFisically(int id) {
        Connection conn = null;
        try {
            conn = Conexao.getConnection();
            PreparedStatement pstm;
            pstm = conn.prepareStatement(Delete);
            pstm.setInt(1, id);
            pstm.execute();
             JOptionPane.showMessageDialog(null, "Dado removido...");
            Conexao.closeConnection(conn, pstm);
             } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir Cliente do banco de"
                    + "dados " + e.getMessage());
        }
    }
    public boolean LogicalDelete(Cliente c){
      boolean r=false;
      if(c!=null){
           Connection conn=null;
           PreparedStatement pstm=null;
           try {
               conn=Conexao.getConnection();
               pstm=conn.prepareStatement(LogicalDelete);
                    pstm.setBoolean(1,c.getStatus());
                    pstm.setInt(2,c.getIdPessoa());
                    pstm.execute();
               r=true;
               Conexao.closeConnection(conn, pstm);                       
          } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro no método Remover Logicamente Cliente:"+e.getMessage());
          }
      }else{
          JOptionPane.showMessageDialog(null,"Dados enviados por parametro estãol váizio");
      }
        return r;
    }
   // ainda nao esta nice esse metodo nao faz sentido oque fiz.....
 public String getCliente(int idCliente){
       String nomePais=null;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getClienteQuery);
            pstm.setInt(1,idCliente);
            rs=pstm.executeQuery();
            while(rs.next()){
                        Cliente c=new Cliente();
                
                        c.setIdPessoa(rs.getInt("idCliente"));
                        c.setIdPessoa(rs.getInt("nomeDoCliente"));
                        c.setIdPessoa(rs.getInt("tipoDocumento"));
                        c.setIdPessoa(rs.getInt("nrDocumento"));
                        c.setIdPessoa(rs.getInt("dataNascimento"));
                        c.setIdPessoa(rs.getInt("localEmissao"));
                        c.setIdPessoa(rs.getInt("estadoCivil"));
                        c.setIdPessoa(rs.getInt("pais"));
                        c.setIdPessoa(rs.getInt("provincia"));
                        c.setIdPessoa(rs.getInt("Distrito"));
                        c.setIdPessoa(rs.getInt("Bairro"));
                        c.setIdPessoa(rs.getInt("NCasa"));
                        c.setIdPessoa(rs.getInt("dataCadastro"));
                        c.setIdPessoa(rs.getInt("status"));
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar Cliente:"+e.getMessage());
        }
         // * tem que retornar uma lista de cliente.....
       return nomePais;
    }

}
