/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Distrito;
import Model.Pais;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author MILG-PC
 */
public class DistritoController {
    private final String INSERT_QUERY = "INSERT INTO Distrito (idProvincia,NomeDistrito,dataCadastro) VALUES (?,?,?)";
    
    private final String UPDATE_QUERY = "UPDATE Distrito SET idProvincia=?,NomeDistrito=? WHERE idDistrito=?";
    private String getIdQuery="Select idDistrito FROM Distrito Where NomeDistrito=?";
     private String getDistritoQuery="Select NomeDistrito FROM Distrito Where idDistrito=?";
    private final String DELETE = "DELETE FROM Distrito WHERE idDistrito=?";
    private final String LIST = "SELECT * FROM Distrito";
    
     public boolean Add(Distrito d){
            boolean r=false;
            if(d!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(INSERT_QUERY);
              
                pstm.setInt(1,d.getIdProvincia());
                pstm.setString(2,d.getNomeDoDistrito());
                pstm.setString(3,d.getDataCadastro());
                pstm.execute();
                r=true;
                } catch (Exception e) {
                   JOptionPane.showMessageDialog(null, "Erro ao regsitar Distrito"
                        + " dados "+ " " + e.getMessage());
                    r=false;
                }
            }else {
            JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
            r=false;
        }
            return r;
    }
     public boolean Update(Distrito d){
            boolean r=false;
            if(d!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(UPDATE_QUERY);
                
                pstm.setInt(1,d.getIdProvincia());
                pstm.setString(2,d.getNomeDoDistrito());
                pstm.setInt(3,d.getIdDistrito());
                pstm.execute(); r=true;
                } catch (Exception e) {
                    
                    JOptionPane.showMessageDialog(null, "Erro ao Alterar dados do Distrito"
                        +" "+ e.getMessage());
                    r=false;
                }
            }else {
            JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
            r=false;
        }
            return r;
    }
     public void Delete(int idDistrito) {
        Connection conn = null;
        try {
            conn = Conexao.getConnection();
            PreparedStatement pstm;
            pstm = conn.prepareStatement(DELETE);
            pstm.setInt(1, idDistrito);
            pstm.execute();
            JOptionPane.showMessageDialog(null,"Dado eliminado..");
            Conexao.closeConnection(conn, pstm);
 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir Distrito do banco de dado:"+"Erro"+" " + e.getMessage());
        }
    }
     
     public List<Distrito> getDistrito() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Distrito> ListaDistrito= new ArrayList<Distrito>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(LIST);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Distrito dst = new Distrito();
                  dst.setIdDistrito(rs.getInt("idPais("));
                dst.setIdProvincia(rs.getInt("IdProvincia"));
                dst.setIdDistrito(rs.getInt("IdDistrito("));
                dst.setNomeDoDistrito(rs.getString("NomeDistrito"));
                dst.setDataCadastro(rs.getString("dataCadastro"));
                ListaDistrito.add(dst);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Distrito"+" " + e.getMessage());
        }
        return ListaDistrito;
    }
   public void populaComboBoxDistrito(JComboBox cboDistrito){
        String sqlSelect="Select* From Distrito";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboDistrito.addItem(rs.getString("NomeDistrito"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox Distrito:"+e.getMessage());
        }
    }
   public void populaComboBoxDistritoWithIdProvincia(JComboBox cboDistrito,  int idProvinca){
        String sqlSelect="Select* From Distrito Where idProvincia like'"+idProvinca+"'";
        Connection conn=null;
        PreparedStatement pstm=null;
        ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(sqlSelect);
            rs=pstm.executeQuery();
            while(rs.next()){
            cboDistrito.addItem(rs.getString("NomeDistrito"));
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Erro ao popular comboBox Distrito:"+e.getMessage());
        }
    }
   public int getIdDistrito(String nomeDistrito){
       int id=0;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getIdQuery);
            pstm.setString(1,nomeDistrito);
            rs=pstm.executeQuery();
            while(rs.next()){
                id=rs.getInt("IdDistrito");
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar id da Distrito:"+e.getMessage());
        }
       return id;
    }
   public String getDistrito(int idDistrito){
       String nomeDistrito=null;
       Connection conn=null;
       PreparedStatement pstm=null;
       ResultSet rs=null;
        try {
            conn=Conexao.getConnection();
            pstm=conn.prepareStatement(getDistritoQuery);
            pstm.setInt(1,idDistrito);
            rs=pstm.executeQuery();
            while(rs.next()){
                nomeDistrito=rs.getString("NomeDistrito");
            }
           Conexao.closeConnection(conn, pstm);       
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Erro ao retornar nome do Distrito:"+e.getMessage());
        }
       return nomeDistrito;
    }
   public ArrayList<Distrito> ReadDistrito() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<Distrito> Listacl = new ArrayList<Distrito>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(LIST);
            rs = pstm.executeQuery();
            while (rs.next()) {
                Distrito  ds= new Distrito();
                ds.setIdProvincia(rs.getInt("idProvincia"));
                ds.setIdDistrito(rs.getInt("IdDistrito"));
                ds.setNomeDoDistrito(rs.getString("NomeDistrito"));
                ds.setDataCadastro(rs.getString("dataCadastro"));
                Listacl.add(ds);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Distrito"+" " + e.getMessage());
        }
        return Listacl;
    }

}
