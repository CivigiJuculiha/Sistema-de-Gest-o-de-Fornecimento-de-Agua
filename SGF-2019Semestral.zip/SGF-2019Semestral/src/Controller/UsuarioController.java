/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

/**
 *
 * @author MILG-PC
 */
import Model.usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import Controller.Conexao;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
public class UsuarioController {
    private final String INSERT_QUERY = "INSERT INTO usuario (NomeCompleto,nomeDoUsuario,nrDocumento,TipoDeDocumento,senha,sector,email,telefone,status,dataRegisto) VALUES (?,?,?,?,?,?,?,?,?,?)";
    
    private final String UPDATE_QUERY = "UPDATE Usuario SET NomeCompleto=?, nomeDoUsuario=?, nrDocumento=?,TipoDeDocumento=?,senha=?,sector=?,email=?,telefone=?,status=?,dataActualizacao=? WHERE idUsuario=?";
    
    private final String DELETE = "DELETE FROM Usuario WHERE idUsuario=?";
    private final String LIST = "SELECT * FROM usuario";
    private final String LISTBYNOMEUSERNAME = "SELECT * FROM Usuario WHERE NomeCompleto=? AND UserName=?";
    private final String GetByIdUsuario = "SELECT * FROM Usuario WHERE idUsuario=?";
    //private final String GetID="SELECT* FROM usuario";
    
    public boolean Add(usuario us){
            boolean r=false;
            if(us!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(INSERT_QUERY);
                pstm.setString(1,us.getNomeCompleto());
                pstm.setString(2,us.getNomeDoUsuario());
                pstm.setString(3,us.getNrDocumento());
                pstm.setString(4,us.getTipoDeDocumento());
                pstm.setString(5,us.getSenha());
                pstm.setString(6,us.getSector());
                pstm.setString(7,us.getEmail());
                pstm.setInt(8,us.getTelefone());
                pstm.setBoolean(9,us.getStatus());
                pstm.setDate(10, (Date) us.getDataRegisto());
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Erro ao regsitar usuario"
                        + " dados "+ " " + e.getMessage());
                    r=true;
                }
            }else {
            JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
            r=false;
        }
            return r;
    }
     public boolean Update(usuario us){
            boolean r=false;
            if(us!=null){
             Connection conn=null;
                try {
                conn = Conexao.getConnection();
                PreparedStatement pstm;
                pstm = conn.prepareStatement(UPDATE_QUERY);
                pstm.setString(1,us.getNomeCompleto());
                pstm.setString(2,us.getNomeDoUsuario());
                pstm.setString(3,us.getNrDocumento());
                pstm.setString(4,us.getTipoDeDocumento());
                pstm.setString(5,us.getSenha());
                pstm.setString(6,us.getSector());
                pstm.setString(7,us.getEmail());
                pstm.setInt(8,us.getTelefone());
                pstm.setBoolean(9,us.getStatus());
                pstm.setDate(10, (Date) us.getDataRegisto());
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Erro ao Alterar dados do usuario"
                        +" "+ e.getMessage());
                    r=true;
                }
            }else {
            JOptionPane.showMessageDialog(null,"O Dado enviado por parâmetro está vazio");
            r=false;
        }
            return r;
    }
     public void Delete(int idUsuario) {
        Connection conn = null;
        try {
            conn = Conexao.getConnection();
            PreparedStatement pstm;
            pstm = conn.prepareStatement(DELETE);
            pstm.setInt(1, idUsuario);
            pstm.execute();
            Conexao.closeConnection(conn, pstm);
 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir usuário do banco de dado:"+"Erro"+" " + e.getMessage());
        }
    }
   
     public List<usuario> getUsuarios() {
        Connection conn = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        ArrayList<usuario> Lista = new ArrayList<usuario>();
        try {
            conn = Conexao.getConnection();
            pstm = conn.prepareStatement(LIST);
            rs = pstm.executeQuery();
            while (rs.next()) {
                usuario us = new usuario();
                us.setIdUsuario(rs.getInt("IdUsuario"));
                us.setNomeCompleto(rs.getString("NomeCompleto"));
                us.setNomeDoUsuario(rs.getString("nomeDoUsuario"));
                us.setSenha(rs.getString("nrDocumento"));
                us.setTipoDeDocumento(rs.getString("TipoDeDocumento"));
                us.setSector(rs.getString("senha"));
                us.setStatus(rs.getBoolean("sector"));
                us.setEmail(rs.getString("email"));
                us.setTelefone(rs.getInt("telefone"));
                us.setStatus(rs.getBoolean("status"));
                us.setDataRegisto(rs.getDate("dataRegisto"));
                
                Lista.add(us);
            }
            Conexao.closeConnection(conn, pstm, rs);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar Usuario"+" " + e.getMessage());
        }
        return Lista;
    }
     
    
}
