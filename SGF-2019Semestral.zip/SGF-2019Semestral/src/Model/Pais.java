/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author MILG-PC
 */
public class Pais {

    /**
     * @return the dataCadastro
     */
    public String getDataCadastro() {
        return dataCadastro;
    }

    /**
     * @param dataCadastro the dataCadastro to set
     */
    public void setDataCadastro(String dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    /**
     * @return the dataActualizacao
     */
    public String getDataActualizacao() {
        return dataActualizacao;
    }

   
    /**
     * @return the status
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(boolean status) {
        this.status = status;
    }

    /**
     * @return the idPais
     */
    public int getIdPais() {
        return idPais;
    }

    /**
     * @param idPais the idPais to set
     */
    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    /**
     * @return the nomeDePais
     */
    public String getNomeDePais() {
        return nomeDePais;
    }

    /**
     * @param nomeDePais the nomeDePais to set
     */
    public void setNomeDePais(String nomeDePais) {
        this.nomeDePais = nomeDePais;
    }
    private int idPais;
    private String nomeDePais;
    private boolean status;
    private String dataCadastro,dataActualizacao;

   
}
