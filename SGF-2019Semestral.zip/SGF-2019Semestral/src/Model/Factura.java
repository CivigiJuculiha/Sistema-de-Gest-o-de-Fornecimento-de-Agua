/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author MILG-PC
 */
public class Factura {
        private int idFactura;
        private double precoUnitatio;
        private String  dataEmisao;
        private int consumo,nrContador;
        private int leituraAnterior,leituraActual;
        private double divida;
        private String nomeCliente,nomeFuncionario;
        private double subTotal,Total;
        
       
}
