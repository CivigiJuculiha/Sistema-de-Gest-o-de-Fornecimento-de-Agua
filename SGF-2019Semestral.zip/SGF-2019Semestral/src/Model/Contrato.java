/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author MILG-PC
 */
public class Contrato extends Pessoa {

    /**
     * @return the idContrato
     */
    public int getIdContrato() {
        return idContrato;
    }

    /**
     * @param idContrato the idContrato to set
     */
    public void setIdContrato(int idContrato) {
        this.idContrato = idContrato;
    }

    /**
     * @return the tipoContrato
     */
    public String getTipoContrato() {
        return tipoContrato;
    }

    /**
     * @param tipoContrato the tipoContrato to set
     */
    public void setTipoContrato(String tipoContrato) {
        this.tipoContrato = tipoContrato;
    }

    /**
     * @return the nrContador
     */
    public long getNrContador() {
        return nrContador;
    }

    /**
     * @param nrContador the nrContador to set
     */
    public void setNrContador(long nrContador) {
        this.nrContador = nrContador;
    }

    /**
     * @return the valorDeAbertrua
     */
    public double getValorDeAbertrua() {
        return valorDeAbertrua;
    }

    /**
     * @param valorDeAbertrua the valorDeAbertrua to set
     */
    public void setValorDeAbertrua(double valorDeAbertrua) {
        this.valorDeAbertrua = valorDeAbertrua;
    }

    /**
     * @return the consumoMinimo
     */
    public int getConsumoMinimo() {
        return consumoMinimo;
    }

    /**
     * @param consumoMinimo the consumoMinimo to set
     */
    public void setConsumoMinimo(int consumoMinimo) {
        this.consumoMinimo = consumoMinimo;
    }

    /**
     * @return the validade
     */
    public String getValidade() {
        return validade;
    }

    /**
     * @param validade the validade to set
     */
    public void setValidade(String validade) {
        this.validade = validade;
    }

    /**
     * @return the dataAbertura
     */
    public String getDataAbertura() {
        return dataAbertura;
    }

    /**
     * @param dataAbertura the dataAbertura to set
     */
    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    /**
     * @return the cliente
     */
    public String getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    /**
     * @return the status
     */
    public Boolean getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }
    private int idContrato;
    private String tipoContrato;
    private long nrContador;
    private double valorDeAbertrua;
    private int consumoMinimo;
    private String validade,dataAbertura;
    private String cliente;
    private Boolean status;
    
}