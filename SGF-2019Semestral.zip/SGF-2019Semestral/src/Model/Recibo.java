/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author MILG-PC
 */
public class Recibo extends Factura {
            private int idRecibo;
            private String nomeCliente;
            private int utilmaLeitura;
            private int consumo;
            private double total;
            private double subTotal,divida;
            private Date dataDeEntrega;
            private Date dataPagamento;
            
}
