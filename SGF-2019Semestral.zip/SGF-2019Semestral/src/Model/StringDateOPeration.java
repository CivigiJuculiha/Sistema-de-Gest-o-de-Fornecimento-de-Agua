/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author MILG-PC
 */
public class StringDateOPeration {

    /**
     * @return the dataCadastro
     */
    public String getDataCadastro() {
        return dataCadastro;
    }

    /**
     * @param dataCadastro the dataCadastro to set
     */
    public void setDataCadastro(String dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    /**
     * @return the dataActualizacao
     */
    public String getDataActualizacao() {
        return dataActualizacao;
    }

    /**
     * @param dataActualizacao the dataActualizacao to set
     */
    public void setDataActualizacao(String dataActualizacao) {
        this.dataActualizacao = dataActualizacao;
    }
     private String dataCadastro;
     private String dataActualizacao;
}
