/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Date;

/**
 *
 * @author MILG-PC
 */
public class Pagamento extends Factura{
    private int idFactura,idPagamento;
    private int idFuncionario;
    private String nomeFuncionario,nomeCliente;
    private int idCliente;
    private int Consumo;
    private double valor;
    private double Divida,Multa;
    private String datePagamento;
    private String dataCadastro;
            
}
