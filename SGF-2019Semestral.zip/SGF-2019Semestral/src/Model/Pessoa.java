/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author MILG-PC
 */
class Pessoa extends StringDateOPeration {

    /**
     * @return the idPessoa
     */
    public int getIdPessoa() {
        return idPessoa;
    }

    /**
     * @param idPessoa the idPessoa to set
     */
    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    /**
     * @return the nomeDoCliente
     */
    public String getNomeDoCliente() {
        return nomeDoCliente;
    }

    /**
     * @param nomeDoCliente the nomeDoCliente to set
     */
    public void setNomeDoCliente(String nomeDoCliente) {
        this.nomeDoCliente = nomeDoCliente;
    }

    /**
     * @return the TipoDeDocumento
     */
    public String getTipoDeDocumento() {
        return TipoDeDocumento;
    }

    /**
     * @param TipoDeDocumento the TipoDeDocumento to set
     */
    public void setTipoDeDocumento(String TipoDeDocumento) {
        this.TipoDeDocumento = TipoDeDocumento;
    }

    /**
     * @return the nrDocumento
     */
    public String getNrDocumento() {
        return nrDocumento;
    }

    /**
     * @param nrDocumento the nrDocumento to set
     */
    public void setNrDocumento(String nrDocumento) {
        this.nrDocumento = nrDocumento;
    }

    /**
     * @return the idade
     */
    public int getIdade() {
        return idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        this.idade = idade;
    }

    /**
     * @return the estadoCivil
     */
    public String getEstadoCivil() {
        return estadoCivil;
    }

    /**
     * @param estadoCivil the estadoCivil to set
     */
    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    /**
     * @return the DataDeNascimento
     */
    public String getDataDeNascimento() {
        return DataDeNascimento;
    }

    /**
     * @param DataDeNascimento the DataDeNascimento to set
     */
    public void setDataDeNascimento(String DataDeNascimento) {
        this.DataDeNascimento = DataDeNascimento;
    }

    /**
     * @return the Sexo
     */
    public String getSexo() {
        return Sexo;
    }

    /**
     * @param Sexo the Sexo to set
     */
    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the telefone
     */
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the NCasa
     */
    public int getNCasa() {
        return NCasa;
    }

    /**
     * @param NCasa the NCasa to set
     */
    public void setNCasa(int NCasa) {
        this.NCasa = NCasa;
    }

    /**
     * @return the pais
     */
    public String getPais() {
        return pais;
    }

    /**
     * @param pais the pais to set
     */
    public void setPais(String pais) {
        this.pais = pais;
    }

    /**
     * @return the provincia
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * @param provincia the provincia to set
     */
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    /**
     * @return the Distrito
     */
    public String getDistrito() {
        return Distrito;
    }

    /**
     * @param Distrito the Distrito to set
     */
    public void setDistrito(String Distrito) {
        this.Distrito = Distrito;
    }

    /**
     * @return the Bairro
     */
    public String getBairro() {
        return Bairro;
    }

    /**
     * @param Bairro the Bairro to set
     */
    public void setBairro(String Bairro) {
        this.Bairro = Bairro;
    }

    /**
     * @return the LocalDeEmissao
     */
    public String getLocalDeEmissao() {
        return LocalDeEmissao;
    }

    /**
     * @param LocalDeEmissao the LocalDeEmissao to set
     */
    public void setLocalDeEmissao(String LocalDeEmissao) {
        this.LocalDeEmissao = LocalDeEmissao;
    }

    /**
     * @return the Quarteirao
     */
    public String getQuarteirao() {
        return Quarteirao;
    }

    /**
     * @param Quarteirao the Quarteirao to set
     */
    public void setQuarteirao(String Quarteirao) {
        this.Quarteirao = Quarteirao;
    }

    /**
     * @return the status
     */
    public Boolean getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }
            private int idPessoa;
            private String nomeDoCliente;
            private String TipoDeDocumento,nrDocumento;
            private int idade;
            private String estadoCivil;
            private String DataDeNascimento;
            private String Sexo;
            private String email;
            private int telefone,NCasa;
            private String pais,provincia,Distrito,Bairro,LocalDeEmissao;
            private  String Quarteirao;
            private Boolean status;

    
}
