/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author MILG-PC
 */
import java.util.Date;
public class usuario extends Pessoa {

    /**
     * @return the telefone
     */
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the idUsuario
     */
    public int getIdUsuario() {
        return idUsuario;
    }

    /**
     * @param idUsuario the idUsuario to set
     */
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    /**
     * @return the NomeCompleto
     */
    public String getNomeCompleto() {
        return NomeCompleto;
    }

    /**
     * @param NomeCompleto the NomeCompleto to set
     */
    public void setNomeCompleto(String NomeCompleto) {
        this.NomeCompleto = NomeCompleto;
    }

    /**
     * @return the nomeDoUsuario
     */
    public String getNomeDoUsuario() {
        return nomeDoUsuario;
    }

    /**
     * @param nomeDoUsuario the nomeDoUsuario to set
     */
    public void setNomeDoUsuario(String nomeDoUsuario) {
        this.nomeDoUsuario = nomeDoUsuario;
    }

    /**
     * @return the nrDocumento
     */
    public String getNrDocumento() {
        return nrDocumento;
    }

    /**
     * @param nrDocumento the nrDocumento to set
     */
    public void setNrDocumento(String nrDocumento) {
        this.nrDocumento = nrDocumento;
    }

    /**
     * @return the TipoDeDocumento
     */
    public String getTipoDeDocumento() {
        return TipoDeDocumento;
    }

    /**
     * @param TipoDeDocumento the TipoDeDocumento to set
     */
    public void setTipoDeDocumento(String TipoDeDocumento) {
        this.TipoDeDocumento = TipoDeDocumento;
    }

    /**
     * @return the senha
     */
    public String getSenha() {
        return senha;
    }

    /**
     * @param senha the senha to set
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }

    /**
     * @return the sector
     */
    public String getSector() {
        return sector;
    }

    /**
     * @param sector the sector to set
     */
    public void setSector(String sector) {
        this.sector = sector;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    public Boolean getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }

    /**
     * @return the dataRegisto
     */
    public Date getDataRegisto() {
        return dataRegisto;
    }

    /**
     * @param dataRegisto the dataRegisto to set
     */
    public void setDataRegisto(Date dataRegisto) {
        this.dataRegisto = dataRegisto;
    }

    /**
     * @return the dataActualizacao
     */
    

    /**
     * @param dataActualizacao the dataActualizacao to set
     */
    public void setDataActualizacao(Date dataActualizacao) {
        this.dataActualizacao = dataActualizacao;
    }
    private int idUsuario;
    private String NomeCompleto,nomeDoUsuario,nrDocumento,TipoDeDocumento,senha,sector,email;
    private Boolean status;
    private int telefone;
    private Date dataRegisto,dataActualizacao;
    
    
}
